# Atualização do AI-CONTEXT — Convidados: busca de documento em Visitantes (2026-11-04)

Aplicar nos arquivos indicados (complementar; não apagar histórico).

## CHANGELOG.md — inserir acima da versão mais recente

## [2.1.22] - 2026-11-04
### Adicionado
- **Convidados (Portal do Morador + app): busca automática do documento em Visitantes.** Ao completar um CPF válido (ou ao sair do campo, no RG), o formulário consulta `GET api/api_portal_convidados.php?acao=buscar_documento`. Visitante da unidade encontrado → nome preenchido e travado, convite vinculado ao cadastro. Não encontrado → aviso "Visitante não cadastrado"; o morador informa o nome e, ao salvar, o convidado é **cadastrado em Visitantes da unidade** (autoria `MORADOR`, CPF formatado) e vinculado ao convite. Resposta do `criar` traz `visitante`: `VINCULADO` | `CADASTRADO` | `EXISTENTE_PORTARIA` | `NAO_CADASTRADO` | `FALHOU`; `cadastrar_visitante:false` desativa o cadastro.
- App Flutter: `GuestDocumentLookup` + `GuestsRemoteDataSource.buscarDocumento()`; `GuestEntity.visitanteId`; formulário com status (encontrado/não cadastrado/CPF inválido), nome travado quando vinculado e vínculo preservado na edição.
- Painel (Registro > Convidados): busca automática ao completar o CPF.
### Corrigido
- **Painel — mensagens do modal "Novo Convidado" apareciam na página atrás do modal** ("CPF inválido", "Visitante não encontrado", erros ao salvar/cancelar). `showFeedback()` agora escreve no `[data-modal-feedback]` do modal aberto (`#convidadoModalFeedback`, `#convidadoCancelFeedback`); mensagens da busca ficam abaixo do campo documento (`#convidadoDocumentoFeedback`, novo estado `.error`). Ao abrir um modal, o aviso dele é limpo.
- Painel: com o campo Nome somente leitura (antes da busca), o envio passava pela validação nativa e só falhava no servidor; agora o formulário pede a busca/nome no próprio modal.
- Portal: editar convite vinculado a visitante não derruba mais o vínculo.
### Segurança / privacidade
- `buscar_documento` só revela nome de visitante **da unidade do morador**. Documento cadastrado em outra unidade responde "não cadastrado" e, ao salvar, não cria duplicado nem vincula (`EXISTENTE_PORTARIA`); a portaria localiza pelo documento na chegada. CPF de morador ativo → 400 `CPF_DE_MORADOR`; CPF inválido → 400 `CPF_INVALIDO`.
- Falha ao cadastrar o visitante não desfaz o convite já salvo (log `[PortalConvidados] falha ao cadastrar visitante`).

## API.md — §18 (Convidados — pré-cadastro do morador), acrescentar
- `GET buscar_documento&tipo_documento=CPF|RG&documento=` → `{encontrado:true, visitante_id, nome, tipo_documento, documento_mascarado}` para visitante ativo da unidade; senão `{encontrado:false, cadastrar_visitante:true, mensagem}`. 400 `CPF_INVALIDO` / `CPF_DE_MORADOR`.
- `POST criar`: sem `visitante_id`, se o documento digitado for de visitante da unidade, vincula; se não existir no condomínio e `cadastrar_visitante` ≠ false, cadastra em `visitantes` (tenant, morador_id, cadastrado_por_tipo/morador_id/nome, observação de origem — colunas opcionais detectadas) após salvar o convite e vincula. Retorno `dados.visitante`.

## BUSINESS_RULES.md — §11, acrescentar
- No Portal/App, ao digitar o documento do convidado o sistema busca em Visitantes da unidade; se não houver cadastro, o convidado é cadastrado automaticamente em Visitantes da unidade ao salvar o convite. Anexos exigidos pela política de visitantes continuam sendo concluídos na chegada (Registro Manual).
- No painel, visitante não encontrado é informado dentro do modal; o convite é salvo com o nome digitado e o cadastro completo de visitante segue na chegada.

## FRONTEND.md — §8, acrescentar
- Portal: `#convDocFeedback` (`.conv-doc-feedback found|notfound|error|loading`), `convidadosDocumentoAlterado()`, `convidadosBuscarDocumento()`, `ConvidadosPortal.docVisitanteId`.
- Painel: `openGuestModal()`, `showFeedback()` com roteamento para `[data-modal-feedback]`, `setDocumentFeedback()`, `scheduleAutoDocumentSearch()`.

## APP_MOBILE_BUSINESS_RULES.md — §1 (linha Convidados) e §6
- Incluir `acao=buscar_documento` (`tipo_documento`, `documento`) na linha Convidados.
- §6: busca automática com CPF completo/RG ao concluir; status visual; nome travado quando visitante encontrado; ao salvar sem cadastro, o servidor cadastra em Visitantes da unidade.

## TESTING.md — §12, acrescentar
- Suíte `tests/convidados_pre_cadastro/` ampliada para **79/79 OK** (MariaDB 10.11 + PHP 8.3): busca de documento (CPF inválido, CPF de morador, visitante da unidade, visitante de outra unidade sem expor nome, documento desconhecido, outro condomínio), cadastro em Visitantes ao salvar (autoria/CPF formatado/vínculo/sem duplicar), vínculo por documento digitado, `EXISTENTE_PORTARIA` sem duplicar, `cadastrar_visitante=false`.
- Playwright: Portal — CPF inválido, encontrado (nome travado), outra unidade (sem nome), não cadastrado → salvar → visitante criado com autoria MORADOR. Painel (módulo real) — CPF inválido, encontrado (busca automática), não cadastrado e erro ao salvar exibidos **dentro do modal**, nada na página; sem erros de JS.
- Não executados: `flutter analyze`/build (SDK indisponível no ambiente).
